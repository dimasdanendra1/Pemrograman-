import tkinter as tk
from tkinter import ttk

def convert_temperature():
    try:
        temperature = float(entry_temperature.get())
        from_unit = combo_from.get()
        to_unit = combo_to.get()

        if from_unit == to_unit:
            result.set(f"{temperature} {from_unit}")
        elif from_unit == "Celsius":
            if to_unit == "Fahrenheit":
                result.set(f"{temperature * 9/5 + 32:.2f} {to_unit}")
            elif to_unit == "Reamur":
                result.set(f"{temperature * 4/5:.2f} {to_unit}")
            elif to_unit == "Kelvin":
                result.set(f"{temperature + 273.15:.2f} {to_unit}")
        elif from_unit == "Fahrenheit":
            if to_unit == "Celsius":
                result.set(f"{(temperature - 32) * 5/9:.2f} {to_unit}")
            elif to_unit == "Reamur":
                result.set(f"{(temperature - 32) * 5/9 * 4/5:.2f} {to_unit}")
            elif to_unit == "Kelvin":
                result.set(f"{(temperature - 32) * 5/9 + 273.15:.2f} {to_unit}")
        elif from_unit == "Reamur":
            if to_unit == "Celsius":
                result.set(f"{temperature * 5/4:.2f} {to_unit}")
            elif to_unit == "Fahrenheit":
                result.set(f"{temperature * 9/4 + 32:.2f} {to_unit}")
            elif to_unit == "Kelvin":
                result.set(f"{temperature * 5/4 + 273.15:.2f} {to_unit}")
        elif from_unit == "Kelvin":
            if to_unit == "Celsius":
                result.set(f"{temperature - 273.15:.2f} {to_unit}")
            elif to_unit == "Fahrenheit":
                result.set(f"{(temperature - 273.15) * 9/5 + 32:.2f} {to_unit}")
            elif to_unit == "Reamur":
                result.set(f"{(temperature - 273.15) * 4/5:.2f} {to_unit}")

    except ValueError:
        result.set("Masukkan suhu yang valid")

# Membuat jendela utama
app = tk.Tk()
app.title("Aplikasi Konversi Suhu")
app.geometry("400x300")
app.configure(bg="blue")  # Warna background biru

# Membuat label dan entry untuk suhu
label_temperature = tk.Label(app, text="Masukkan Suhu:", font=("Times New Roman", 12), fg="black", bg="blue")
label_temperature.grid(row=0, column=0, padx=10, pady=10)

entry_temperature = tk.Entry(app, font=("Times New Roman", 12), bg="lightblue", fg="black")  # Warna latar belakang
entry_temperature.grid(row=0, column=1, padx=10, pady=10)

# Membuat label dan combobox untuk unit suhu
label_from = tk.Label(app, text="Dari:", font=("Times New Roman", 12), fg="black", bg="blue")
label_from.grid(row=1, column=0, padx=10, pady=10)

combo_from = ttk.Combobox(app, values=["Celsius", "Fahrenheit", "Reamur", "Kelvin"], font=("Times New Roman", 12), foreground="black")
combo_from.grid(row=1, column=1, padx=10, pady=10)
combo_from.set("Celsius")

label_to = tk.Label(app, text="Ke:", font=("Times New Roman", 12), fg="black", bg="blue")
label_to.grid(row=2, column=0, padx=10, pady=10)

combo_to = ttk.Combobox(app, values=["Celsius", "Fahrenheit", "Reamur", "Kelvin"], font=("Times New Roman", 12), foreground="black")
combo_to.grid(row=2, column=1, padx=10, pady=10)
combo_to.set("Celsius")

# Membuat tombol konversi
button_convert = tk.Button(app, text="Konversi", command=convert_temperature, font=("Times New Roman", 12), bg="blue", fg="black")
button_convert.grid(row=3, column=0, columnspan=2, pady=10)

# Membuat label untuk menampilkan hasil konversi
result = tk.StringVar()
label_result = tk.Label(app, textvariable=result, font=("Times New Roman", 14, "bold"), fg="black", bg="blue")
label_result.grid(row=4, column=0, columnspan=2, pady=10)

# Menjalankan aplikasi
app.mainloop()
